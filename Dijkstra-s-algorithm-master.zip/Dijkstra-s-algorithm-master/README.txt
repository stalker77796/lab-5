Dijkstra-s-algorithm. LAB 5.
Student: Samrega A.A. IU8 - 21.